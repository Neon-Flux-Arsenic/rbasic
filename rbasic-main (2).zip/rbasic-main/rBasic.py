# Imports
import sys

# Classes
class Line:
    line_number = 0
    tokens = []

    def __init__(self, line_number, tokens):
        self.line_number = line_number
        self.tokens = tokens


# Variables
program = []

# File handling
if len(sys.argv) < 2:
    path = "funny_monkey.rps"
else:
    path = sys.argv[1]

with open(path) as source:
    file = source.readlines()

# Lexer
for line, line_number in enumerate(file):
    line = line.strip()

    if not line:
        continue

    tokens = line.split()
    match tokens[0]:
        case "set":
            program.append(Line(line_number,tokens[1:]))

print( program )