import sys
import math

def fatal ( message, line=None ):
	if line != None:
		print(f"Line {line}: ", end="")
		
	print( f"Fatal exception: {message}" )
	exit( 1 )

def debug( message ):
	print( f"Debug: {message}" )

file = sys.argv[ 1 ]
with open( file ) as contents:
	source = contents.readlines()


program = []
variables = {}

# first_inst = 0
# last_inst = 0


for line in source:
	line = line.strip()
	
	# if line == "\n" : continue
	#if line == "" : continue
	
	program.append( line.split( " " ) )


def get_str( line ):
	return " ".join( line )

def var_or_lit( literal ) :
	if literal in variables:
		return variables[ literal ]
	
	if type( literal ) == float or type( literal ) == int:
		return float( literal )
	
	if literal.isnumeric():
		return float( literal )
	else:
		return str( literal )

program_counter = 0

def execute():
	global program_counter
	
	if program_counter >= len( program ):
		print( program_counter )
		# print( first_inst )
		# print(f"LAST INSTRUCTION: {last_inst}")
		print()
		return

	line = program[ program_counter ]
	program_counter += 1
	
	match ( line[ 0 ] ):
		case "print":
			message = []
			
			for token in line[ 1: ]:
				if token[ 0 ] == "$":
					message.append( str( var_or_lit( token[ 1: ] ) ) )
				else:
					message.append( token )
				
			print( get_str( message ) )
		case "set":
			name = line[ 1 ]
			
			if len(line) <= 2:
				fatal( f"Missing value for assignment", program_counter )
			
			if len( line ) > 3:
				variables[ name ] = get_str( line[ 2: ] )
			else:
				variables[ name ] = var_or_lit( line[ 2 ] )
		case "for":
			index = line[ 1 ]
			inc = line[ 2 ]
			target = line[ 3 ]
			
			first_inst = program_counter
			last_inst = program_counter
			
			depth = 1
			debug( program[ program_counter: ] )
			for token_list in program[ program_counter: ]:
				
				if token_list[ 0 ] == "for":
					depth += 1
				elif token_list[ 0 ] == "end":
					depth -= 1
				
				if depth == 0 : break
				last_inst += 1
			
			while var_or_lit( index ) <= var_or_lit( target ):
				program_counter = first_inst
				for pc in range( first_inst, last_inst ):
					# debug( program_counter )
					# program_counter = pc + 1
					execute()
				
				if index in variables:
					variables[ index ] += var_or_lit( inc )
				else:
					index = float( index ) + var_or_lit( inc )
			
			program_counter = last_inst
		
		case "if":
			pass
		
	if len( line ) <= 2:
		return
	
	match ( line[ 1 ] ):
		case "sum":
			name = line[ 0 ]
			sum = 0
			
			for literal in line[ 2: ]:
				value = var_or_lit( literal )
				if type( value ) != float:
					print( "Value of variable \"" + literal + "\" is" + str( var_or_lit( literal ) ) )
					fatal( "Attempted to sum a non-number with a number!", line )
				
				sum += value
			
			variables[ name ] = sum
		case "sub":
			name = line[ 0 ]
			sum = var_or_lit( line[ 2 ] )
			
			for literal in line[ 3: ]:
				value = var_or_lit( literal )
				if type( value ) != float:
					print( "Value of variable \"" + literal + "\" is" + str( var_or_lit( literal ) ) )
					fatal( "Attempted to sum a non-number with a number!", line )
				
				sum -= value
			
			variables[ name ] = sum
		
		case "mul":
			name = line[ 0 ]
			sum = var_or_lit( line[ 2 ] )
			
			for literal in line[ 3: ]:
				value = var_or_lit( literal )
				if type( value ) != float:
					print( "Value of variable \"" + literal + "\" is" + str( var_or_lit( literal ) ) )
					fatal( "Attempted to multiply a non-number by a number!", line )
				
				sum *= value
			
			variables[ name ] = sum

		case "div":
			name = line[ 0 ]
			sum = var_or_lit( line[ 2 ] )
			
			for literal in line[ 3: ]:
				value = var_or_lit( literal )
				if type( value ) != float:
					print( "Value of variable \"" + literal + "\" is" + str( var_or_lit( literal ) ) )
					fatal( "Attempted to divide a non-number by a number!", line )
				
				sum /= value
			
			variables[ name ] = sum


print( program_counter )
print( len( program ) )
while program_counter < len( program ):
	execute()


print( program, variables )
